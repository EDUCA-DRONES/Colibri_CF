# Information: https://clover.coex.tech/programming

import rospy
from abc import ABC, abstractmethod
from drone import Drone
from camera import Camera
from servo import Servo

class Task(ABC):
    '''
    An abstract class to write mission
    '''
    drone = Drone()
    camera = Camera()
    servo = Servo(14)
    
    @abstractmethod
    def run(self):
        raise Exception("Need implementation.")

    def return_to_launch_confim(self):
        pass

    def change_servo_pin(self, gpio:int):
        self.servo.gpio = gpio

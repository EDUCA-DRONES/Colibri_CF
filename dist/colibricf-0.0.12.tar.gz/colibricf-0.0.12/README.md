# Colibri Code Functions 
